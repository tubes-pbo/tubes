package Buku;

import java.util.HashMap;
import java.util.Map;

public class BukuHashMap {
    public static void main(String[] args) {

        // membuat objek hashmap
        HashMap<String, Buku> books = new HashMap<String, Buku>();
        
        // membuat objek buku
        Buku bukuJava = new Buku("TBFO", "Muttaqin");
        Buku bukuKotlin = new Buku("PBO", "Chanzu");
        Buku bukuAndroid = new Buku("Pemrograman Android", "Niqattum");
        
        // mengisi objek hashmap dengan objek buku
        books.put("java", bukuJava);
        books.put("kotlin", bukuKotlin);
        books.put("android", bukuAndroid);
        
        // cetak semua buku
        for(Map.Entry b: books.entrySet()){
            Buku buku = (Buku) b.getValue();
            System.out.println(b.getKey() + ": "+ buku.getTitle() + ": "+ buku.getAuthor() );
        }
        
    }
}
