package Person;

import java.util.*;

public class Mahasiswa extends Person {
    int nim=2;
    
    public Mahasiswa(String nama, String prodi, int smt, double ukt) {
        super(nama, prodi, smt, ukt);
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Map <Integer,Person> data = new HashMap();
        
        Person[] mhs = new Person[5];
        mhs[0].nim=2;
        mhs[0]=new Person("apa","iya",20,1.0);
        data.put(mhs[0].nim, mhs[0]);

        System.out.println("\n"+"Pilih Menu \n"+ 
                            " 1. Menghapus data mahasiswa dan menampilkan data yang dihapus\n" +
                            " 2. Menampilkan isi map sebelum dan sesudah operasi diatas\n"+
                            " 0. Keluar\n");
        int pilih;
        do{
            System.out.print("\nMasukkan Menu = ");
            pilih = sc.nextInt();
            switch(pilih){
                case 1 :
                    System.out.print("\nMasukkan key ( nomor ) Mahasiswa yang akan dihapus = ");
                    int cariKey = sc.nextInt();
                    if (data.containsKey(cariKey)) { 
                        System.out.println(data.get(cariKey));
                        data.remove(cariKey, data.get(cariKey));
                    }else{
                        System.out.println("Data (Key) yang ingin anda hapus tidak ditemukan");
                    }
                    break;
                case 2 :
                    if(data.isEmpty()){
                        System.out.println("Data kosong");
                    }
                    for (Integer i : data.keySet()) {
                        System.out.println("NIM : " + i + " Data Mahasiswanya = " + data.get(i));
                    }
                    break;
                case 3 :
                    int cariNIM = sc.nextInt();
                    if(data.containsValue(cariNIM=mhs[0].nim)){
                        System.out.println(mhs[0].nim);
                    }
                    break ;
                case 0 :
                    System.exit(0);
                default :
                    System.out.println("Menu tidak ada, inputkan kembali ");
                    break;
            }
        }while(pilih!=0);
    }

}