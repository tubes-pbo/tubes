package Person;

public class Person {
    int nim,smt;
    String nama, prodi;
    double ukt;
   
    public Person(String nama, String prodi, int smt, double ukt) {
        this.nama = nama;
        this.prodi = prodi;
        this.smt = smt;
        this.ukt = ukt;
    }
    
    public String toString() {
        return "Mahasiswa{" +  
                "nama=" + nama + 
                ", prodi=" + prodi + 
                ", smt=" + smt + 
                ", ukt=" + ukt + '}';
    }
}