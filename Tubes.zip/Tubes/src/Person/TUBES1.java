package Person;

import java.util.*;

public class TUBES1 extends Mahasiswa {

    public TUBES1(String nama, String prodi, int smt, double ukt){
        super(nama, prodi, smt, ukt);
        nim=10;
    }
    public static void main(String[] args) {
        
    }
}
