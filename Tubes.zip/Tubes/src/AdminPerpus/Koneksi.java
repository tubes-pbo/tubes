package AdminPerpus;

import com.mysql.jdbc.Driver;
import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class Koneksi {
    private static Connection Koneksi;
    Statement stm;
    public Koneksi(){
        
        MysqlDataSource mds = new MysqlDataSource();
        mds.setUser("root");
        mds.setPassword("");
        mds.setDatabaseName("Perpustakaan");
        
        try {
            Koneksi = mds.getConnection();
            stm = Koneksi.createStatement();
        } catch (SQLException ex) {
           JOptionPane.showMessageDialog(null,"KONEKSI GAGAL "+ex.getMessage());
        }
    }
    public Connection getKoneksi(){
        return this.Koneksi;
    }
    
    public static void main(String[] args) {
        Koneksi k = new Koneksi();
    }
}
